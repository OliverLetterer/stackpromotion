//
//  main.m
//
//  Created by Oliver Letterer on 08.04.22.
//

#import <Foundation/Foundation.h>

@import StackPromotion;

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        size_t size = [NSSStackArray sizeWithMaximumCapacity:100];
        __volatile uint8_t data[size];
        [NSSStackArray initializeBytes:data maximumCapacity:100];
        
        NSSStackArray *array = (__bridge id)(void *)data;
        
        [array addObject:@"String"];
        
        NSLog(@"%d", [array containsObject:@"No String"]);
        NSLog(@"%d", [array containsObject:@"String"]);
        
        for (NSInteger i = 0; i < 100; i++) {
            [array addObject:@"String"];
        }
    }
    return 0;
}
