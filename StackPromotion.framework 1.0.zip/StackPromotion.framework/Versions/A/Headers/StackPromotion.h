//
//  StackPromotion.h
//  StackPromotion
//
//  Created by Oliver Letterer on 08.04.22.
//

#import <Foundation/Foundation.h>

//! Project version number for StackPromotion.
FOUNDATION_EXPORT double StackPromotionVersionNumber;

//! Project version string for StackPromotion.
FOUNDATION_EXPORT const unsigned char StackPromotionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StackPromotion/PublicHeader.h>

#import <StackPromotion/NSSStackArray.h>
