//
//  NSSStackArray.h
//  StackPromotion
//
//  Created by Oliver Letterer on 08.04.22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSSStackArray : NSObject

+ (size_t)sizeWithMaximumCapacity:(NSInteger)capacity;

+ (void)initializeBytes:(volatile uint8_t *)bytes maximumCapacity:(NSInteger)capacity;

- (void)addObject:(id)object;
- (BOOL)containsObject:(id)object;

@end

NS_ASSUME_NONNULL_END
